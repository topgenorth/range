using System;
using Gtk;

using Medsphere.Widgets;

namespace Medsphere.Demo
{
	public class IconLayoutDemo : DemoWindow
	{
#region public methods
		public IconLayoutDemo () : base ("Icon Layout Demo")
		{
			VBox box = new VBox ();

			layout = new IconLayout ();

			BoxCellRenderer box_r = new BoxCellRenderer ();
			box_r.PackStart (new PixbufCellRenderer ());
			box_r.PackStart (new TextCellRenderer ());
			layout.CellRenderer = box_r;

			layout.CellDataFunc = new CairoCellRendererDataFunc (Renderer);
			
			ListStore store = new ListStore (typeof (string));
			store.AppendValues (Gtk.Stock.About);
			store.AppendValues (Gtk.Stock.Add);
			store.AppendValues (Gtk.Stock.Apply);
			store.AppendValues (Gtk.Stock.Bold);
			store.AppendValues (Gtk.Stock.Cancel);
			store.AppendValues (Gtk.Stock.Cdrom);
			store.AppendValues (Gtk.Stock.Clear);
			store.AppendValues (Gtk.Stock.Close);
			store.AppendValues (Gtk.Stock.ColorPicker);
			store.AppendValues (Gtk.Stock.Convert);
			store.AppendValues (Gtk.Stock.Connect);
			layout.Model = store;
			
			ScrolledWindow sw = new ScrolledWindow ();
			sw.ShadowType = ShadowType.In;
			sw.Add (layout);
			box.PackStart (sw, true, true, 0);

			VBox modifiers = new VBox ();
			modifiers.Spacing = 6;

			HBox layout_modifier = new HBox ();
			layout_modifier.Spacing = 6;
			layout_modifier.PackStart (new Label ("Layout Mode:"), false, false, 0);
			
			ComboBox layout_modes = ComboBox.NewText ();
			layout_modes.Changed += new EventHandler (OnLayoutModeChanged);
			layout_modes.AppendText ("Horizontal");
			layout_modes.AppendText ("Vertical");
			layout_modes.AppendText ("Grid");
			layout_modes.Active = 2;
			layout_modifier.PackStart (layout_modes, false, false, 0);

			modifiers.PackStart (layout_modifier, true, true, 0);

			HBox affinity_modifier = new HBox ();
			affinity_modifier.Spacing = 6;
			affinity_modifier.PackStart (new Label ("Layout Affinity:"), false, false, 0);

			ComboBox affinity_modes = ComboBox.NewText ();
			affinity_modes.Changed += new EventHandler (OnAffinityModeChanged);
			affinity_modes.AppendText ("Horizontal");
			affinity_modes.AppendText ("Vertical");
			affinity_modes.Active = 0;
			affinity_modifier.PackStart (affinity_modes, false, false, 0);

			modifiers.PackStart (affinity_modifier, true, true, 0);

			HBox selection_modifier = new HBox ();
			selection_modifier.Spacing = 6;
			selection_modifier.PackStart (new Label ("Selection Mode:"), false, false, 0);

			ComboBox selection_modes = ComboBox.NewText ();
			selection_modes.Changed += new EventHandler (OnSelectionModeChanged);
			selection_modes.AppendText ("None");
			selection_modes.AppendText ("Single");
			selection_modes.AppendText ("Browse");
			selection_modes.AppendText ("Multiple");
			selection_modes.Active = 1;
			selection_modifier.PackStart (selection_modes, false, false, 0);

			modifiers.PackStart (selection_modifier, true, true, 0);

			box.PackStart (modifiers, false, false, 0);

			Add (box);

			ShowAll ();
		}
#endregion

#region private methods
		private void OnLayoutModeChanged (object o, EventArgs args)
		{
			layout.LayoutMode = (LayoutMode)((ComboBox)o).Active;
		}

		private void OnAffinityModeChanged (object o, EventArgs args)
		{
			layout.LayoutAffinity = (LayoutAffinity)((ComboBox)o).Active;
		}

		private void OnSelectionModeChanged (object o, EventArgs args)
		{
			layout.SelectionMode = (SelectionMode)((ComboBox)o).Active;
		}

		private void Renderer (IconLayout view, ICairoCellRenderer renderer, TreeModel model, TreeIter iter)
		{
			BoxCellRenderer box = (BoxCellRenderer)renderer;
			PixbufCellRenderer pix = (PixbufCellRenderer)box.Children[0];
			TextCellRenderer text = (TextCellRenderer)box.Children[1];

			string stock_id = (string)model.GetValue (iter, 0);
			pix.Pixbuf = view.RenderIcon (stock_id, IconSize.Dialog, null);
			text.Text = stock_id;
		}
#endregion

#region private fields
		private IconLayout layout;
#endregion
	}
}
