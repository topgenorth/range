using System;
using Gtk;

using Medsphere.Widgets;

namespace Medsphere.Demo
{
	public class CPanedDemo : DemoWindow
	{
		private readonly int n_columns = 5;

		private TreeView tree_view;

		private Expander expander;
		private TextView text_view;

		public CPanedDemo () : base ("CPaned Demo")
		{
			VPaned vpaned = new VPaned ();
			Add (vpaned);

			ScrolledWindow top_scrolled_window = new ScrolledWindow ();
			vpaned.Pack1 (top_scrolled_window, true, false);

			Type[] type_array = new Type[n_columns];
			for (int x = 0; x < n_columns; x++) {
				type_array[x] = typeof (string);
			}
 
			string[] words = DemoData.Text.Split (' ');
			ListStore store = new ListStore (type_array);
			TreeIter tree_iter = store.Append ();

			for (int x = 0; x < words.Length; x++) {
				int col = x % n_columns;
				store.SetValue (tree_iter, col, words[x]);

				if (col == n_columns - 1) {
					tree_iter = store.Append ();
				}
			}

			tree_view = new TreeView ();
			top_scrolled_window.Add (tree_view);

			for (int x = 0; x < n_columns; x++) {
				tree_view.AppendColumn ("Column " + x.ToString (),
				                        new CellRendererText (), "text", x);
			}

			tree_view.Model = store;

			expander = new Expander ("Details");
			vpaned.Pack2 (expander, true, false);

			Alignment align = new Alignment (0.0f, 0.0f, 1.0f, 1.0f);
			align.LeftPadding = 12;
			expander.Add (align);

			ScrolledWindow bottom_scrolled_window = new ScrolledWindow ();
			bottom_scrolled_window.ShadowType = ShadowType.EtchedIn;
			align.Add (bottom_scrolled_window);

			text_view = new TextView ();
			text_view.Editable = false;
			bottom_scrolled_window.Add (text_view);

			tree_view.Selection.Changed +=
				new EventHandler (OnTreeViewSelectionChanged);

			new CPaned (vpaned);
		}

		private void OnTreeViewSelectionChanged (object o, EventArgs a)
		{
			TreeIter tree_iter;
			TextBuffer buffer = text_view.Buffer;

			if (tree_view.Selection.GetSelected (out tree_iter)) {
				buffer.Clear ();
				TextIter text_iter = buffer.StartIter;

				for (int x = 0; x < n_columns; x++) {
					string value =
						tree_view.Model.GetValue (tree_iter, x) as string;
					buffer.Insert (ref text_iter,
					               String.Format ("{0}: {1}\n", x, value));
				}

				expander.Expanded = true;
			} else {
				buffer.Text = String.Empty;
				expander.Expanded = false;
			}
		}
	}
}
