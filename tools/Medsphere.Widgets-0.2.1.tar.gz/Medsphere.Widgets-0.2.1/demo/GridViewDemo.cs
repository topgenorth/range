using System;
using Gtk;

using Medsphere.Widgets;

namespace Medsphere.Demo
{
	public class GridViewDemo : DemoWindow
	{
		private readonly int n_columns = 5;

		private GridView grid_view;

		public GridViewDemo () : base ("GridViewDemo")
		{
			VBox vbox = new VBox (false, 6);
			Add (vbox);

			Type[] type_array = new Type[n_columns];
			for (int x = 0; x < n_columns; x++) {
				type_array[x] = typeof (string);
			}

			string[] words = DemoData.Text.Split (' ');
			ListStore store = new ListStore (type_array);
			TreeIter tree_iter = store.Append ();

			for (int x = 0; x < words.Length; x++) {
				int col = x % n_columns;
				store.SetValue (tree_iter, col, words[x]);

				if (col == n_columns - 1) {
					tree_iter = store.Append ();
				}
			}

			grid_view = new GridView ();
			grid_view.HscrollbarPolicy = PolicyType.Automatic;
			grid_view.VscrollbarPolicy = PolicyType.Automatic;
			vbox.PackStart (grid_view);

			for (int x = 0; x < n_columns; x++) {
				CellRendererText renderer = new CellRendererText ();

				grid_view.AppendColumn (renderer, "Text", x);
			}

			grid_view.Model = store;

			vbox.PackStart (new HSeparator (), false, false, 0);

			HBox hbox = new HBox (false, 6);
			vbox.PackStart (hbox, false, false, 0);

			hbox.PackStart (new Label ("Orientation:"), false, false, 0);

			ComboBox orientation_combo_box = ComboBox.NewText ();
			hbox.PackStart (orientation_combo_box, false, false, 0);
			orientation_combo_box.AppendText ("Vertical");
			orientation_combo_box.AppendText ("Horizontal");
			orientation_combo_box.Active = 0;
			orientation_combo_box.Changed +=
				new EventHandler (OnOrientationComboBoxChanged);

			hbox.PackStart (new Label ("Row Headers:"), false, false, 0);

			SpinButton row_headers_spin_button =
				new SpinButton (0, n_columns, 1);
			row_headers_spin_button.Value = grid_view.NRowHeaders;
			row_headers_spin_button.Changed +=
				new EventHandler (OnRowHeadersSpinButtonValueChanged);
			hbox.PackStart (row_headers_spin_button, false, false, 0);

			hbox.PackStart (new Label ("Col Headers:"), false, false, 0);

			SpinButton col_headers_spin_button =
				new SpinButton (0, store.IterNChildren (), 1);
			col_headers_spin_button.Value = grid_view.NColHeaders;
			col_headers_spin_button.Changed +=
				new EventHandler (OnColHeadersSpiButtonValueChanged);
			hbox.PackStart (col_headers_spin_button, false, false, 0);
		}

		private void OnOrientationComboBoxChanged (object o, EventArgs a)
		{
			grid_view.Orientation =
				(o as ComboBox).Active == 0 ?
					Orientation.Vertical : Orientation.Horizontal;
		}

		private void OnRowHeadersSpinButtonValueChanged (object o, EventArgs a)
		{
			grid_view.NRowHeaders = (o as SpinButton).ValueAsInt;
		}

		private void OnColHeadersSpiButtonValueChanged (object o, EventArgs a)
		{
			grid_view.NColHeaders = (o as SpinButton).ValueAsInt;
		}
	}
}
