using System;
using Gtk;

using Medsphere.Widgets;

namespace Medsphere.Demo
{
	public class FBoxDemo : DemoWindow
	{
		private readonly int n_widgets = 30;

		private FBox fbox1, fbox2;

		public FBoxDemo () : base ("FBox Demo")
		{
			VBox vbox = new VBox (false, 6);
			Add (vbox);

			HBox hbox = new HBox (false, 6);
			vbox.PackStart (hbox, false, false, 0);

			hbox.PackStart (new Label ("Leading:"), false, false, 0);

			SpinButton leading_spin_button = new SpinButton (0, 50, 1);
			hbox.PackStart (leading_spin_button, false, false, 0);

			vbox.PackStart (new HSeparator (), false, false, 0);

			HPaned hpaned = new HPaned ();
			vbox.PackStart (hpaned);

			fbox1 = new FBox ();
			hpaned.Add1 (fbox1);

			fbox2 = new FBox ();
			hpaned.Add2 (fbox2);

			string[] words = DemoData.Text.Split (' ');
			for (int x = 0; x < n_widgets && x < words.Length; x ++) {
				fbox1.Append (new Button (words[x]));
				fbox2.Append (new Button (words[x]));
			}

			leading_spin_button.Value = fbox1.Leading;
			leading_spin_button.ValueChanged +=
				new EventHandler (OnLeadingSpinButtonChanged);
		}

		private void OnLeadingSpinButtonChanged (object o, EventArgs a)
		{
			fbox1.Leading =
			fbox2.Leading = (int)(o as SpinButton).Value;
		}
	}
}
