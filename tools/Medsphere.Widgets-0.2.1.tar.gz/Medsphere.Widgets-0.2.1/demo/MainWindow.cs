using System;
using System.Reflection;
using Gtk;
using Glade;

namespace Medsphere.Demo
{
	public class DemoWindow : Window
	{
		public DemoWindow (string title) : base (title)
		{
			Resize (640, 480);
		}
	}

	public class MainWindow : DemoWindow
	{
		private readonly string glade_filename = "demo.glade";
		private readonly string glade_widgetname = "MainHPaned";
		private readonly string[] widgets =
		{
			"CPaned",
			"FBox",
			"GridView",
			"Graph",
			"IconLayout"
		};

		[Glade.Widget] private TreeView WidgetsTreeView;
		[Glade.Widget] private TextView InfoTextView;
		[Glade.Widget] private TextView SourceTextView;

		private Assembly assembly;

		private static void Main (string[] args)
		{
			Application.Init ();
			new MainWindow ();
			Application.Run ();
		}

		public MainWindow () : base ("Medsphere Code Demos")
		{
			assembly = this.GetType ().Assembly;

			XML xml =
				new XML (assembly, glade_filename, glade_widgetname, null);
			xml.BindFields (this);
			Add (xml.GetWidget (glade_widgetname));

			SourceTextView.ModifyFont (Pango.FontDescription.FromString ("monospace"));

			ListStore widgets_store = new ListStore (
				typeof (string), // the name of the widget
				typeof (Window) // the demo window, or null
			);

			foreach (string widget in widgets) {
				widgets_store.AppendValues (widget);
			}

			WidgetsTreeView.AppendColumn (null, new CellRendererText (),
			                              new TreeCellDataFunc (NameRenderer));
			WidgetsTreeView.Model = widgets_store;

			WidgetsTreeView.RowActivated +=
				new RowActivatedHandler (OnWidgetsTreeViewRowActivated);
			WidgetsTreeView.Selection.Changed +=
				new EventHandler (OnWidgetsTreeViewSelectionChanged);

			SetSizeRequest (640, 480);
			
			DeleteEvent += new DeleteEventHandler (OnDeleteEvent);

			ShowAll ();
		}
		
		private void OnDeleteEvent (object sender, DeleteEventArgs args)
		{
			Application.Quit ();
			args.RetVal = true;
		}

		private void NameRenderer (TreeViewColumn col, CellRenderer renderer,
		                           TreeModel model, TreeIter iter)
		{
			try {
				string widget = (string)model.GetValue (iter, 0) as string;
				Window window = (Window)model.GetValue (iter, 1) as Window;

				CellRendererText crt = (CellRendererText)renderer;

				crt.Text = widget;
				crt.Style = window == null ?
				           Pango.Style.Normal : Pango.Style.Italic;
			} catch { }
		}

		private void OnWidgetsTreeViewRowActivated (object o,
		                                            RowActivatedArgs a)
		{
			TreeIter iter;
			if (!WidgetsTreeView.Selection.GetSelected (out iter)) {
				return;
			}

			string widget = WidgetsTreeView.Model.GetValue (iter, 0) as string;
			Window window = WidgetsTreeView.Model.GetValue (iter, 1) as Window;

			if (window != null) {
				window.Hide ();
			}

			Type demo_type =
				assembly.GetType ("Medsphere.Demo." + widget + "Demo");

			try {
				window = Activator.CreateInstance (demo_type) as Window;
				WidgetsTreeView.Model.SetValue (iter, 1, window);
				window.ShowAll ();
			} catch (Exception ex) {
				Console.WriteLine ("Could not instantiate {0}", widget);
				Console.WriteLine (ex);
				return;
			}

			if (demo_type == null) {
				return;
			}
		}

		private void OnWidgetsTreeViewSelectionChanged (object o, EventArgs a)
		{
			TreeIter iter;
			if (!WidgetsTreeView.Selection.GetSelected (out iter)) {
				InfoTextView.Buffer.Text =
				SourceTextView.Buffer.Text = String.Empty;

				return;
			}

			string widget = WidgetsTreeView.Model.GetValue (iter, 0) as string;

			InfoTextView.Buffer.Text = widget;

			try {
				System.IO.Stream stream =
					assembly.GetManifestResourceStream (widget + "Demo.cs");
				SourceTextView.Buffer.Text =
					new System.IO.StreamReader (stream).ReadToEnd ();
			} catch (Exception ex) {
				Console.WriteLine (ex);
			}


		}
	}

	public class DemoData
	{
		public static readonly string Text =
"OpenVista is a cost-effective, open, trusted and complete EHR which enhances patient safety, increases clinical and operational efficiency and provides an opportunity to improve quality of care delivery. Healthcare provider organizations are encouraged to access this software and see first hand how our commercialized version of the Veterans Affairs' FOIA VistA can be leveraged outside of the VA to support the goal of higher quality healthcare. We anticipate that an open source approach will assist in revolutionizing healthcare by enabling many more healthcare delivery organizations to successfully adopt such technology for the benefit of their patients and their businesses. Medsphere is focused on developing an open source community centered on Medsphere OpenVista®. We welcome your participation in OpenVista projects. If you have an idea on how to improve quality, enhance functionality, or accelerate innovation in OpenVista we encourage and welcome your input -- please join our mailing lists.";
	}
}
